(function(){
  const root = document.querySelector('.airstager-root');
  if(!root) return;
  const photoInput = document.getElementById('airstager-photo');
  const generateBtn = document.getElementById('airstager-generate');
  const previewWrap = document.getElementById('airstager-preview-wrap');
  const saveBtn = document.getElementById('airstager-save');
  const exportCsvBtn = document.getElementById('airstager-export-csv');
  const exportImgBtn = document.getElementById('airstager-export-images');
  const printBtn = document.getElementById('airstager-print');
  const titleInput = document.getElementById('airstager-title');
  const notesInput = document.getElementById('airstager-notes');
  const printArea = document.getElementById('airstager-print-area');

  let originalImage = null;
  let projects = []; // saved projects loaded from server/localStorage

  // simple SVG overlays per style (furniture silhouettes) - minimal illustrative assets
  const overlays = {
    modern: `<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 800 600'><rect x='60' y='350' width='680' height='160' rx='8' fill='rgba(30,64,175,0.6)'/><rect x='120' y='260' width='240' height='120' rx='12' fill='rgba(243,244,246,0.7)'/><rect x='420' y='240' width='220' height='140' rx='12' fill='rgba(250,250,250,0.6)'/></svg>`,
    minimal: `<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 800 600'><rect x='80' y='330' width='640' height='180' rx='6' fill='rgba(17,24,39,0.5)'/><rect x='140' y='260' width='180' height='110' rx='8' fill='rgba(255,255,255,0.85)'/></svg>`,
    luxury: `<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 800 600'><rect x='40' y='320' width='720' height='200' rx='12' fill='rgba(0,0,0,0.6)'/><ellipse cx='240' cy='260' rx='140' ry='90' fill='rgba(255,245,238,0.9)'/><rect x='420' y='220' width='260' height='160' rx='12' fill='rgba(255,250,240,0.9)'/></svg>`,
    scandi: `<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 800 600'><rect x='90' y='340' width='620' height='160' rx='5' fill='rgba(249,250,251,0.85)'/><rect x='140' y='270' width='220' height='110' rx='10' fill='rgba(96,165,250,0.12)'/></svg>`
  };

  function readImage(file, cb){
    const fr = new FileReader();
    fr.onload = function(e){
      const img = new Image();
      img.onload = function(){ cb(img); };
      img.src = e.target.result;
    };
    fr.readAsDataURL(file);
  }

  photoInput.addEventListener('change', function(e){
    const f = e.target.files[0];
    if(!f) return;
    readImage(f, function(img){ originalImage = img; });
  });

  function makeCanvasFromImage(img, w){
    const ratio = img.width / img.height;
    const canvas = document.createElement('canvas');
    const width = w || Math.min(1000, img.width);
    canvas.width = width;
    canvas.height = Math.round(width / ratio);
    const ctx = canvas.getContext('2d');
    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
    return canvas;
  }

  function renderPreviews(){
    previewWrap.innerHTML = '';
    if(!originalImage) return alert('Upload a room photo first');

    const checked = Array.from(document.querySelectorAll('.airstager-styles input[type=checkbox]:checked')).map(i=>i.value);
    if(checked.length===0) return alert('Choose at least one style');

    checked.forEach(style => {
      const canvas = makeCanvasFromImage(originalImage, 720);
      const ctx = canvas.getContext('2d');
      if(style==='modern') {
        ctx.fillStyle = 'rgba(10,20,60,0.06)';
        ctx.fillRect(0,0,canvas.width,canvas.height);
      } else if(style==='minimal') {
        ctx.fillStyle = 'rgba(255,255,255,0.06)';
        ctx.fillRect(0,0,canvas.width,canvas.height);
      } else if(style==='luxury') {
        ctx.fillStyle = 'rgba(0,0,0,0.12)';
        ctx.fillRect(0,0,canvas.width,canvas.height);
      } else if(style==='scandi') {
        ctx.fillStyle = 'rgba(250,245,235,0.04)';
        ctx.fillRect(0,0,canvas.width,canvas.height);
      }

      const svg = overlays[style] || '';
      const svgBlob = new Blob([svg], {type:'image/svg+xml;charset=utf-8'});
      const url = URL.createObjectURL(svgBlob);
      const oImg = new Image();
      oImg.onload = function(){
        ctx.drawImage(oImg, 0, canvas.height*0.45, canvas.width, canvas.height*0.55);
        URL.revokeObjectURL(url);
        addPreviewCard(canvas, style);
      };
      oImg.src = url;
    });
  }

  function addPreviewCard(canvas, style){
    const card = document.createElement('div');
    card.className = 'airstager-card';
    const img = document.createElement('img');
    img.className = 'airstager-canvas';
    img.src = canvas.toDataURL('image/png');
    const meta = document.createElement('div');
    meta.className = 'airstager-meta';
    const title = titleInput.value || 'Untitled listing';
    const notes = notesInput.value || '';
    meta.innerHTML = `<strong>${title} — ${style}</strong><div class="airstager-small">${notes}</div><div style="margin-top:8px;"><button class="airstager-btn airstager-download">Download PNG</button></div>`;

    card.appendChild(img);
    card.appendChild(meta);
    previewWrap.appendChild(card);

    meta.querySelector('.airstager-download').addEventListener('click', function(){
      const a = document.createElement('a');
      a.href = img.src;
      a.download = (title + '-' + style + '.png').replace(/\s+/g,'-').toLowerCase();
      document.body.appendChild(a);
      a.click();
      a.remove();
    });
  }

  generateBtn.addEventListener('click', function(){ renderPreviews(); });

  saveBtn.addEventListener('click', function(){
    const title = titleInput.value || 'Untitled listing';
    const notes = notesInput.value || '';
    const imgs = Array.from(previewWrap.querySelectorAll('img')).map(i=>i.src);
    if(imgs.length===0) return alert('Generate previews first');
    const project = { title: title, notes: notes, images: imgs, date: (new Date()).toISOString() };
    if(typeof airstagerAjax !== 'undefined' && airstagerAjax.ajax_url){
      jQuery.post(airstagerAjax.ajax_url, { action: 'airstager_save', payload: JSON.stringify(project), nonce: airstagerAjax.nonce })
        .done(function(res){ if(res.success) alert('Project saved to your account'); else { localSave(project); alert('Saved locally (not logged in)'); } })
        .fail(function(){ localSave(project); alert('Saved locally (AJAX failed)'); });
    } else {
      localSave(project);
      alert('Saved locally');
    }
  });

  function localSave(project){
    const key = 'airstager_projects';
    const s = localStorage.getItem(key);
    let arr = s ? JSON.parse(s) : [];
    arr.push(project);
    localStorage.setItem(key, JSON.stringify(arr));
  }

  exportCsvBtn.addEventListener('click', function(){
    const rows = [['title','style','image_data_url','date','notes']];
    const title = titleInput.value || '';
    const notes = notesInput.value || '';
    Array.from(previewWrap.querySelectorAll('.airstager-card')).forEach(card=>{
      const img = card.querySelector('img').src;
      const header = card.querySelector('.airstager-meta strong').innerText || '';
      const style = header.split('—').pop().trim();
      rows.push([title, style, img, (new Date()).toISOString(), notes]);
    });
    if(rows.length===1) return alert('No previews to export');
    const csv = rows.map(r=>r.map(c=>'"'+String(c).replace(/"/g,'""')+'"').join(',')).join('\n');
    const blob = new Blob([csv], {type:'text/csv;charset=utf-8;'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'airstager-export-' + (new Date()).toISOString().slice(0,10) + '.csv';
    document.body.appendChild(a); a.click(); a.remove();
    URL.revokeObjectURL(url);
  });

  exportImgBtn.addEventListener('click', function(){
    const imgs = Array.from(previewWrap.querySelectorAll('img')).map(i=>i.src);
    if(imgs.length===0) return alert('No previews to export');
    if(confirm('Download all staged images one-by-one? (Browser will prompt multiple downloads)')){
      imgs.forEach((src, idx)=>{
        const a = document.createElement('a');
        a.href = src;
        a.download = 'staged-' + (idx+1) + '.png';
        document.body.appendChild(a);
        a.click();
        a.remove();
      });
    }
  });

  printBtn.addEventListener('click', function(){
    const title = titleInput.value || 'Staged Listing';
    const notes = notesInput.value || '';
    const imgs = Array.from(previewWrap.querySelectorAll('img')).map(i=>i.src);
    if(imgs.length===0) return alert('Generate previews first');
    let html = '<h1>' + title + '</h1><p>' + notes + '</p>';
    imgs.forEach((src, idx)=>{
      html += '<div style="page-break-inside:avoid;margin-bottom:12px;"><img src="'+src+'" style="max-width:100%;height:auto;border:1px solid #eee;padding:6px"/></div>';
    });
    printArea.style.display = 'block';
    printArea.innerHTML = html;
    window.print();
    setTimeout(()=>{ printArea.style.display = 'none'; }, 1000);
  });

  function tryLoadSaved(){
    if(typeof airstagerAjax !== 'undefined' && airstagerAjax.ajax_url){
      jQuery.post(airstagerAjax.ajax_url, { action: 'airstager_load', nonce: airstagerAjax.nonce })
        .done(function(res){ if(res.success && res.data){ console.log('Loaded user projects', res.data); } })
        .fail(function(){ /* ignore */ });
    }
  }
  tryLoadSaved();

})();
