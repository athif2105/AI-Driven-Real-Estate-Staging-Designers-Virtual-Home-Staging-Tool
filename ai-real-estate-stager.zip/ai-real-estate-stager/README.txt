AI‑Driven Real Estate Staging Designers (Lightweight)
====================================================

Install:
1. Upload the zip to WordPress Plugins -> Add New -> Upload Plugin, or unzip into wp-content/plugins/
2. Activate the plugin.
3. Use the shortcode [ai_stager] on any post or page, or add the plugin's admin page via the WP admin menu "AI Stager".

Features included:
- Frontend staging UI: upload room photo, select multiple staging styles, generate preview composites entirely client-side using Canvas + SVG overlays.
- Styles: Modern, Minimal, Luxury, Scandinavian (illustrative overlays included).
- Export staged PNG, export CSV of previews, print-to-PDF (browser Print -> Save as PDF).
- Save projects to user meta when logged in, fallback to localStorage otherwise.
- No external API calls or AI backends — this is an educational simulation you can later replace with real AI image-generation APIs.

Limitations & notes:
- This plugin simulates AI staging using overlay assets and filters. For true AI-generated virtual staging (photorealistic furniture insertion), you will need to integrate with an image-generation/virtual-staging API or run local ML models; that requires additional work, API keys, and careful handling of copyrighted content.
- Exporting multiple images as a single ZIP client-side requires a library like JSZip; I avoided external libs to keep the plugin lightweight. If you want, I can add JSZip so the plugin zips images for download automatically.
- Security: treat this plugin as a starting point — sanitize inputs and harden saving endpoints before using in production.

Disclaimer:
Results are AI-simulated for educational use only. Always verify with professionals and follow AI regulations.

